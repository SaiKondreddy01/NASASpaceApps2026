import { afterEach, expect, it, vi } from 'vitest';
import { newBatch } from './batches';
it('reports actual completed frames as the server produces them', async () => {
  vi.useFakeTimers();
  const make = (status: string, count: number) => ({ batch_id:'batch-1', status, image_count:count, warnings:[], data:{frames:Array.from({length:count},(_,i)=>({epoch_id:String(i)}))} });
  const replies = [make('queued',0), make('running',1), make('running',2), make('ready',3)];
  vi.stubGlobal('fetch', vi.fn(async () => ({ok:true,json:async()=>replies.shift()})));
  const changes: string[] = [];
  const seen: number[] = [];
  const result = newBatch({ra:1,dec:1,fov:.2,detector:1,view_mode:'full_frame',target:'',name:''}, (message,batch) => { changes.push(message); seen.push(batch.data.frames.length); });
  await vi.runAllTimersAsync();
  expect((await result).data.frames).toHaveLength(3);
  expect(changes).toEqual(['Queued: 0/10 images', 'Processing: 1/10 images', 'Processing: 2/10 images']);
  expect(seen).toEqual([0,1,2]);
});
afterEach(() => {vi.useRealTimers();vi.unstubAllGlobals();});
