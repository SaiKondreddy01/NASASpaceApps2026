import { useState } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { BlinkPlayer } from "./BlinkPlayer";
import { FullFrameStage } from "./FullFrameStage";
import { TimeMachinePanel } from "./TimeMachinePanel";
import { interpolateTrack } from "../lib/timeMachineMath";
import type { CutoutFrame, TimeTrackResponse } from "../types";
const frame: CutoutFrame = {epoch_id:"1",obs_id:"1",mjd:60914,time_iso:"2025-08-27",bandpass:"SPHEREx-D1",detector:1,image_url:"/image.png",float_shape:[113,117],wcs:{CRPIX1:59,CRPIX2:57,CRVAL1:269.4498066,CRVAL2:4.7226162,CDELT1:-0.001708333,CDELT2:0.001708333,NAXIS1:117,NAXIS2:113}};
const track: TimeTrackResponse = {name:"Barnard's Star",target_id:"barnards_star",is_mover:true,start_year:2010,end_year:2035,n:2,catalog_ra:269.452,catalog_dec:4.693,ref_epoch:2016,proper_motion:{},points:[{date_iso:"2010-01-01",decimal_year:2010,mjd:55197,ra:269.453417,dec:4.676098},{date_iso:"2035-01-01",decimal_year:2035,mjd:64328,ra:269.447832,dec:4.748057}],key_dates:[],honesty:"prediction",method:"test",source:"pm_table"};
let lastArc: number[] = [];
let markerPositions: number[][] = [];
let drawnImages = 0;
const context = new Proxy({} as CanvasRenderingContext2D, {get(target, prop) { if (prop === "drawImage") return () => {drawnImages++;}; if (prop === "arc") return (...args:number[]) => {lastArc=args;}; if (prop === "fillText") return (text:string) => {if (text.startsWith("Predicted ")) markerPositions.push([...lastArc]);}; if (prop === "measureText") return () => ({width:10}); return (target as any)[prop] ?? (() => {}); },set(target, prop,value){(target as any)[prop]=value;return true;}});
class FakeImage { crossOrigin=""; src=""; naturalWidth=117; naturalHeight=113; width=117; height=113; decode(){return Promise.resolve();} }
function FullHarness() { const [year,setYear]=useState(2010); return <><TimeMachinePanel track={track} year={year} onYearChange={setYear} frameDecimalYear={2025} reducedMotion={true}/><FullFrameStage frames={[frame]} fieldRa={269.4498066} fieldDec={4.7226162} subtractZodi={false} timePoint={interpolateTrack(track.points,year)} timeTrail={track.points}/></>; }
function Harness() { const [year,setYear]=useState(2010); return <><TimeMachinePanel track={track} year={year} onYearChange={setYear} frameDecimalYear={2025} reducedMotion={true}/><BlinkPlayer frames={[frame]} reducedMotion={true} timePoint={interpolateTrack(track.points,year)} timeTrail={track.points} fieldRa={269.4498066} fieldDec={4.7226162}/></>; }
beforeEach(() => {markerPositions=[]; drawnImages=0;
 vi.stubGlobal("ImageData", class { constructor(public data: Uint8ClampedArray, public width: number, public height: number) {} });
 vi.stubGlobal("fetch", vi.fn(async () => ({ok:true,json:async()=>({naxis1:117,naxis2:113,shape:[113,117],wcs:frame.wcs,stats:{p01:0,p995:1},tile_size:256,n_levels:1})})));
lastArc=[];vi.stubGlobal("Image",FakeImage);vi.spyOn(HTMLCanvasElement.prototype,"getContext").mockReturnValue(context as any);});
afterEach(() => {cleanup();vi.restoreAllMocks();vi.unstubAllGlobals();});
vi.mock("../lib/tileCache", () => ({ TileLru: class { clear() {} }, chooseLevel: () => 0, fetchImageTile: async (_cache:any, opts:any) => ({data:new Float32Array(opts.expectNx * opts.expectNy), nx:opts.expectNx, ny:opts.expectNy}), fetchFlagsTile: vi.fn() }));
describe("Time Machine date to canvas",()=>{
 it("draws the full-frame image tiles", async()=>{
  render(<FullHarness/>);
  await waitFor(()=>expect(drawnImages).toBeGreaterThan(0), {timeout:4000});
 });
 it("moves the marker through the full frame renderer", async()=>{
  render(<FullHarness/>);
  await waitFor(()=>expect(markerPositions.length).toBeGreaterThan(0), {timeout:4000});
  const before=markerPositions[markerPositions.length-1]; markerPositions=[];
  fireEvent.change(screen.getByRole("slider",{name:"Year"}),{target:{value:"2035"}});
  await waitFor(()=>expect(markerPositions.length).toBeGreaterThan(0), {timeout:4000});
  const after=markerPositions[markerPositions.length-1];
  expect(Math.hypot(after[0]-before[0],after[1]-before[1])).toBeGreaterThan(10);
 });
 it("moves Barnard's predicted marker when the actual year slider changes", async()=>{
  render(<Harness/>);
  await waitFor(()=>expect(markerPositions.length).toBeGreaterThan(0));
  const before=markerPositions[markerPositions.length-1]; markerPositions=[];
  fireEvent.change(screen.getByRole("slider",{name:"Year"}),{target:{value:"2035"}});
  await waitFor(()=>expect(markerPositions.length).toBeGreaterThan(0));
  const after=markerPositions[markerPositions.length-1];
  expect(Math.hypot(after[0]-before[0],after[1]-before[1])).toBeGreaterThan(10);
 });
});
