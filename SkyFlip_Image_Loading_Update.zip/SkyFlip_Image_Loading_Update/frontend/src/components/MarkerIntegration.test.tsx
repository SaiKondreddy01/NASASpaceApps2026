import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, waitFor } from "@testing-library/react";
import { BlinkPlayer } from "./BlinkPlayer";
import type { CutoutFrame } from "../types";

const frame: CutoutFrame = {epoch_id:"1",obs_id:"1",mjd:60000,time_iso:"2023-01-01",bandpass:"SPHEREx-D1",detector:1,image_url:"/image.png",array_shape:[117,117],wcs:{CRPIX1:59,CRPIX2:59,CRVAL1:100,CRVAL2:20,CDELT1:-0.001,CDELT2:0.001,NAXIS1:117,NAXIS2:117}};
let lastArc: number[] = [];
let markerPositions: number[][] = [];
const context = new Proxy({} as CanvasRenderingContext2D, {get(target, prop) {
  if (prop === "arc") return (...args:number[]) => {lastArc = args;};
  if (prop === "fillText") return (text:string) => {if (text.startsWith("Predicted ")) markerPositions.push([...lastArc]);};
  if (prop === "measureText") return () => ({width:10});
  return (target as any)[prop] ?? (() => {});
},set(target, prop,value){(target as any)[prop]=value;return true;}});
class FakeImage { crossOrigin=""; src=""; naturalWidth=117; naturalHeight=117; width=117; height=117; decode(){return Promise.resolve();} }
beforeEach(() => { markerPositions=[]; lastArc=[]; vi.stubGlobal("Image", FakeImage); vi.spyOn(HTMLCanvasElement.prototype,"getContext").mockReturnValue(context as any); });
afterEach(() => {cleanup();vi.restoreAllMocks();vi.unstubAllGlobals();});
describe("Time Machine marker", () => {
 it("redraws the predicted circle at a new pixel when the chosen year changes", async () => {
  const {rerender}=render(<BlinkPlayer frames={[frame]} reducedMotion={true} timePoint={{ra:100,dec:20,decimal_year:2010}} timeTrail={[]} fieldRa={100} fieldDec={20} />);
  await waitFor(() => expect(markerPositions.length).toBeGreaterThan(0));
  const initial=markerPositions[markerPositions.length-1];
  markerPositions=[];
  rerender(<BlinkPlayer frames={[frame]} reducedMotion={true} timePoint={{ra:100.01,dec:20.01,decimal_year:2035}} timeTrail={[]} fieldRa={100} fieldDec={20} />);
  await waitFor(() => expect(markerPositions.length).toBeGreaterThan(0));
  const after=markerPositions[markerPositions.length-1];
  expect(after[0]).not.toBeCloseTo(initial[0]);
  expect(after[1]).not.toBeCloseTo(initial[1]);
 });
});
