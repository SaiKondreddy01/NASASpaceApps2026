# Image loading and progress update

Choose **View → Full image (full frame)** or **Cutout (target crop)** below the image. Switching modes opens an existing matching saved batch when one exists, or requests a new one. To force a fresh batch, choose the mode and click **Request new batch of 10**.

During a new batch, the counter reflects completed images reported by the backend. Completed images appear while the remaining images are still processing. Partial results are retained when fewer than 10 images can be retrieved. If the archive or image tiles cannot be loaded, the app shows an error; cached cutouts are labeled and are not full frames.

Full-frame rendering now respects FITS PC rotation matrices and reports tile failures. Time Machine remains in the project.

Verification in this environment: the production frontend build succeeded; 105 frontend tests passed, followed by 8 focused frontend tests after an additional rendering test was added. Thirteen backend batch and tile tests passed, including a test of intermediate persisted progress. Backend and frontend started and the proxy health endpoint and cached manifest returned HTTP 200. Tests using mocked image data are not a verification of live NASA/IRSA retrieval. The browser could not connect to the local test server in this environment, and the external archive was not verified.
