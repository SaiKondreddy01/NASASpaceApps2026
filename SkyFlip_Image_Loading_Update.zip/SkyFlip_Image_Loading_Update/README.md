# SkyFlip — merged working copy

SkyFlip is a SPHEREx image viewer built on Part 2, with archive tools from Part 1. Images and reports are candidates for review, not confirmed discoveries. See MERGE_REPORT.md for what was tested and current limitations.

## Windows setup

Install Python 3.11 or 3.12 and a current Node.js release (Vite 8 needs Node 20.19+ or 22.12+). Open PowerShell in this folder. In the first terminal:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
.\.venv\Scripts\python.exe -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000
```

Leave it running. In a second PowerShell terminal, open the same project folder:

```powershell
cd frontend
npm ci
npm run dev
```

Open http://127.0.0.1:5173 . The frontend proxies `/api` to port 8000. Open http://127.0.0.1:8000/api/status to check backend and database; `/docs` provides interactive API schemas. Archive tools are linked from the viewer. Venv is an isolated Python dependency folder, not a server; you do not have to activate it when using the commands above.

## Files and data

`frontend/` is the React/Vite interface; `backend/app/` is FastAPI; `backend/app/batches.py` handles saved batches; `backend/app/archive/` contains Part 1 archive tools; `backend/app/observations/` handles reports; `backend/migrations/` contains report schema; `frontend/public/demo-data/` contains labeled cached demo data. SQLite and image cache initialize automatically in `.cache/` on first use. Keep this directory to preserve batches, reports and cached images; back it up before moving or deleting it. Batch metadata depends on its corresponding cached images remaining available.

`.env.example` describes optional settings. It is not automatically loaded: set PowerShell environment variables before starting the backend, for example `$env:SKYFLIP_CACHE_DIR = 'C:\SkyFlipData'`. `SKYFLIP_OBSERVATIONS_DB` changes the database path; `SKYFLIP_HTTP_TIMEOUT` and `SKYFLIP_BATCH_TIMEOUT` configure batch timeouts. Set `SKYFLIP_ADMIN_TOKEN` before using protected report administration. Do not put secrets in source code. The frontend proxy can be changed with `SKYFLIP_BACKEND_URL`; frontend port with `SKYFLIP_FRONTEND_PORT`.

## Batches and API

Choose coordinates or a preset, choose cutout or full frame, then request a batch. Loading may take time: the API queues work and saves each successful frame. A partial result explains when fewer than 10 could be retrieved. Saved batches can be selected again. Requests to create saved batches use live archive data and do not silently substitute demo data; the original viewer can display separately labeled cached demo data if live loading fails.

- `GET /api/health`, `GET /api/status`: service and database status.
- `GET /api/targets`: presets; `GET /api/epochs` and `/api/cutouts`: existing viewer endpoints.
- `POST /api/batches`: create an asynchronous batch. `GET /api/batches`: list; `GET /api/batches/{id}`: status and frames; `GET /api/batches/{id}/frames/{index}`: frame metadata.
- `POST /api/observations`: submit a report. The complete schema, required frame highlights and examples appear at `/docs`; reports with a batch ID are checked against the saved batch. Admin reads require the configured token.
- `/api/archive/*`: Part 1 search, analysis and image endpoints. The original Part 1 frontend now calls this prefix. See `/docs` for all routes and schemas.

Example, in a third PowerShell window:

```powershell
$body = @{ra=133.79512917; dec=-7.24514722; fov=0.1; detector=1; view_mode='target_crop'; idempotency_key='example-batch-0001'} | ConvertTo-Json
$batch = Invoke-RestMethod http://127.0.0.1:8000/api/batches -Method Post -ContentType 'application/json' -Body $body
Invoke-RestMethod "http://127.0.0.1:8000/api/batches/$($batch.batch_id)"
```

The response starts `queued` and later becomes `ready`, `partial`, or `failed`. Poll it until complete. Use `full_frame` for full-frame mode and a new idempotency key for a new request. `data.frames` holds the ordered metadata; inspect warnings and failures. Each observation may be from a different band or detector; apparent changes are not proof of motion.

## Troubleshooting

- **Failed to fetch:** confirm both terminals remain running and `/api/status` opens. Use the frontend address (port 5173), not the API root. Check the backend terminal for errors. Live IRSA requests require internet; archive failure is different from a stopped backend.
- **Port already in use:** another process is using 8000 or 5173. Stop the appropriate old server or change the backend `--port` and set `SKYFLIP_BACKEND_URL` to the matching address in the frontend terminal; use `SKYFLIP_FRONTEND_PORT` for the frontend.
- **Missing Python module:** install requirements into this project's `.venv`, then start using that same interpreter. Use `npm ci` in `frontend` for JavaScript dependencies.
- **Database unavailable:** ensure the cache/database path is writable and disk space is available. Avoid running multiple backend instances against the same database while recovering queued jobs.

## Interface and image interaction

The welcome screen opens the exploration workspace. Choose a view mode, then request a batch; choose a saved batch from the selector. In full-frame mode drag the image to pan; the Pan, Box zoom and Select tools are separate. Reports use a separate image-space highlight editor. Full-frame report previews are generated from cached detector pixels; the highlight editor uses native image dimensions. The full-frame preview route is `/api/frame/{obs_id}/{detector}/preview`.

This integration is a draft pending an end-to-end browser and live IRSA test; see UI_MERGE_REPORT.md for exact results.

## Time Travel and How Fast Is It?

Choose one of the five preset targets. Open **Motion** to use Time machine: scrub the 2010-2035 year slider, play or pause the predicted position, adjust its speed, reset the year, or choose a SPHEREx date tick from the currently loaded images. The marker and line are catalog-based predictions overlaid on the selected image; they are not historical photographs or discoveries. **Center on object** moves the viewer toward the predicted position when available. Reduced-motion settings disable automatic time animation. Variable-star control tracks are held fixed in this visualization even though their small catalog motion is used in the speed calculation.

Open **How fast is it?** for the current target's catalog-derived sideways speed, proper motion, distance and citations. Changing presets changes the object. Custom fields have no curated speed/track. Track and speed require the backend; keep it running. Endpoints are `GET /api/track?target=wise0855&start=2010&end=2035&n=101` and `GET /api/motion-speed?target=wise0855`. No database migration is required for these features. See FINAL_MERGE_REPORT.md and FINAL_TEST_REPORT.md for detailed limitations and verification.

The How Fast Is It? tab displays an approximate Sun-relative total speed only when the catalog contains both sideways and radial velocities. The two components and their sources are listed separately. For objects without a verified radial velocity in this project, total speed is unavailable; the sideways component is an approximate lower bound. Values are catalog estimates, not derived from the selected batch of images. See FINAL_MERGE_REPORT.md for source and quality details.
